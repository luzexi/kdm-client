#!/bin/sh
gradle clean build publishToMavenLocal
