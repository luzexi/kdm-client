//
//  AppDelegate.h
//  ImageCropView
//
//  Created by Ming Yang on 12/27/12.
//
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
